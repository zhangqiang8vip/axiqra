Axiqra logo-assets package

This package contains PNG logo assets extracted from the generated design boards.
Best for quick frontend/prototype use.

Folders:
- variants/: main logo lockups
- icons/: icon-only assets, app icon variants, favicon, size exports
- reference_boards/: original design boards

Notes:
- These are raster PNG assets, not editable SVG/Figma source files.
- Some assets were cropped from generated boards for quick use.
