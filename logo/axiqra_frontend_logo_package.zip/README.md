# Axiqra Frontend Logo Package

This is a frontend-ready logo package for Axiqra.

## Recommended project placement

Copy the `public/` folder into your frontend project root.

For Next.js / React:

```txt
your-project/
  public/
    favicon.ico
    site.webmanifest
    logo/
      logo-horizontal.svg
      logo-horizontal-white.svg
      icon.svg
      icon-mono.svg
      logo-horizontal.png
      icon-512.png
      ...
  components/
    AxiqraLogo.tsx
```

## Main files

- `/public/logo/logo-horizontal.svg` — recommended navbar logo
- `/public/logo/logo-horizontal-white.svg` — use on dark backgrounds
- `/public/logo/icon.svg` — recommended icon / mark
- `/public/logo/icon-mono.svg` — monochrome icon
- `/public/favicon.ico` — browser favicon
- `/public/site.webmanifest` — PWA / app manifest

## Usage

HTML:

```html
<img src="/logo/logo-horizontal.svg" alt="Axiqra" width="180" height="45" />
```

Next.js:

```tsx
import { AxiqraLogo } from "@/components/AxiqraLogo";

<AxiqraLogo />
<AxiqraLogo variant="icon" />
<AxiqraLogo theme="dark" />
```

## Note

The SVG files are clean frontend-ready vector reconstructions based on the generated visual direction.
The PNG files are extracted/raster assets from the generated design boards and are suitable for quick prototype use.
