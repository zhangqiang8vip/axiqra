import Image from "next/image";

type AxiqraLogoProps = {
  variant?: "horizontal" | "icon";
  theme?: "light" | "dark";
  className?: string;
  priority?: boolean;
};

export function AxiqraLogo({
  variant = "horizontal",
  theme = "light",
  className = "",
  priority = false,
}: AxiqraLogoProps) {
  const src =
    variant === "icon"
      ? "/logo/icon.svg"
      : theme === "dark"
        ? "/logo/logo-horizontal-white.svg"
        : "/logo/logo-horizontal.svg";

  const alt = variant === "icon" ? "Axiqra icon" : "Axiqra logo";

  return (
    <Image
      src={src}
      alt={alt}
      width={variant === "icon" ? 40 : 180}
      height={variant === "icon" ? 40 : 45}
      priority={priority}
      className={className}
    />
  );
}
