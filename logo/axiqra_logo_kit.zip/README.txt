Axiqra Logo Kit - PNG original design boards

- 01_primary_logo_presentation.png
- 02_brand_guideline_sheet.png
- 03_logo_variations_sheet.png
- 04_app_icon_favicon_kit.png
- 05_ui_usage_mockups.png